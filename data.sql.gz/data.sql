-- MySQL dump 10.13  Distrib 5.6.48, for Linux (x86_64)
--
-- Host: localhost    Database: huanrenka
-- ------------------------------------------------------
-- Server version	5.6.48-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cr_admin_extension_histories`
--

DROP TABLE IF EXISTS `cr_admin_extension_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_extension_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cr_admin_extension_histories_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_extension_histories`
--

LOCK TABLES `cr_admin_extension_histories` WRITE;
/*!40000 ALTER TABLE `cr_admin_extension_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_extension_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_extensions`
--

DROP TABLE IF EXISTS `cr_admin_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_extensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_enabled` tinyint(4) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_admin_extensions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_extensions`
--

LOCK TABLES `cr_admin_extensions` WRITE;
/*!40000 ALTER TABLE `cr_admin_extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_menu`
--

DROP TABLE IF EXISTS `cr_admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `show` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_menu`
--

LOCK TABLES `cr_admin_menu` WRITE;
/*!40000 ALTER TABLE `cr_admin_menu` DISABLE KEYS */;
INSERT INTO `cr_admin_menu` VALUES (1,0,1,'Index','feather icon-bar-chart-2','/','',1,'2022-07-11 02:12:40',NULL),(2,0,2,'Admin','feather icon-settings','','',1,'2022-07-11 02:12:40',NULL),(3,2,3,'Users','','auth/users','',1,'2022-07-11 02:12:40',NULL),(4,2,4,'Roles','','auth/roles','',1,'2022-07-11 02:12:40',NULL),(5,2,5,'Permission','','auth/permissions','',1,'2022-07-11 02:12:40',NULL),(6,2,6,'Menu','','auth/menu','',1,'2022-07-11 02:12:40',NULL),(7,2,7,'Extensions','','auth/extensions','',1,'2022-07-11 02:12:40',NULL),(8,0,8,'系统设置','fa-cog','/setting','',1,'2022-07-12 05:41:48','2022-07-12 05:41:48');
/*!40000 ALTER TABLE `cr_admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_permission_menu`
--

DROP TABLE IF EXISTS `cr_admin_permission_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_permission_menu` (
  `permission_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `cr_admin_permission_menu_permission_id_menu_id_unique` (`permission_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_permission_menu`
--

LOCK TABLES `cr_admin_permission_menu` WRITE;
/*!40000 ALTER TABLE `cr_admin_permission_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_permission_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_permissions`
--

DROP TABLE IF EXISTS `cr_admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_admin_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_permissions`
--

LOCK TABLES `cr_admin_permissions` WRITE;
/*!40000 ALTER TABLE `cr_admin_permissions` DISABLE KEYS */;
INSERT INTO `cr_admin_permissions` VALUES (1,'Auth management','auth-management','','',1,0,'2022-07-11 02:12:40',NULL),(2,'Users','users','','/auth/users*',2,1,'2022-07-11 02:12:40',NULL),(3,'Roles','roles','','/auth/roles*',3,1,'2022-07-11 02:12:40',NULL),(4,'Permissions','permissions','','/auth/permissions*',4,1,'2022-07-11 02:12:40',NULL),(5,'Menu','menu','','/auth/menu*',5,1,'2022-07-11 02:12:40',NULL),(6,'Extension','extension','','/auth/extensions*',6,1,'2022-07-11 02:12:40',NULL);
/*!40000 ALTER TABLE `cr_admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_role_menu`
--

DROP TABLE IF EXISTS `cr_admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_role_menu` (
  `role_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `cr_admin_role_menu_role_id_menu_id_unique` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_role_menu`
--

LOCK TABLES `cr_admin_role_menu` WRITE;
/*!40000 ALTER TABLE `cr_admin_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_role_permissions`
--

DROP TABLE IF EXISTS `cr_admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_role_permissions` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `cr_admin_role_permissions_role_id_permission_id_unique` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_role_permissions`
--

LOCK TABLES `cr_admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `cr_admin_role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_role_users`
--

DROP TABLE IF EXISTS `cr_admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_role_users` (
  `role_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `cr_admin_role_users_role_id_user_id_unique` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_role_users`
--

LOCK TABLES `cr_admin_role_users` WRITE;
/*!40000 ALTER TABLE `cr_admin_role_users` DISABLE KEYS */;
INSERT INTO `cr_admin_role_users` VALUES (1,1,'2022-07-11 02:12:40','2022-07-11 02:12:40');
/*!40000 ALTER TABLE `cr_admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_roles`
--

DROP TABLE IF EXISTS `cr_admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_roles`
--

LOCK TABLES `cr_admin_roles` WRITE;
/*!40000 ALTER TABLE `cr_admin_roles` DISABLE KEYS */;
INSERT INTO `cr_admin_roles` VALUES (1,'Administrator','administrator','2022-07-11 02:12:40','2022-07-11 02:12:40');
/*!40000 ALTER TABLE `cr_admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_settings`
--

DROP TABLE IF EXISTS `cr_admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_settings` (
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_settings`
--

LOCK TABLES `cr_admin_settings` WRITE;
/*!40000 ALTER TABLE `cr_admin_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_admin_users`
--

DROP TABLE IF EXISTS `cr_admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_admin_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_admin_users`
--

LOCK TABLES `cr_admin_users` WRITE;
/*!40000 ALTER TABLE `cr_admin_users` DISABLE KEYS */;
INSERT INTO `cr_admin_users` VALUES (1,'admin','$2y$10$OSMVlfLVtoPY46Opv5CYfeQ8vGvUn6BkFegoRtJzjsOis2c8bl6H.','超级管理员',NULL,NULL,'2022-07-11 02:12:40','2022-07-11 02:16:09');
/*!40000 ALTER TABLE `cr_admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_customer_balance_logs`
--

DROP TABLE IF EXISTS `cr_customer_balance_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_customer_balance_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `scene` tinyint(3) DEFAULT '0' COMMENT '10提现 11提现服务费 12提现驳回返还 20充值 30抵扣',
  `flow_type` tinyint(3) DEFAULT '0' COMMENT '资金流动类型 (10收入 20支出)',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '变动金额',
  `before_balance` decimal(10,2) DEFAULT '0.00' COMMENT '变动前金额',
  `after_balance` decimal(10,2) DEFAULT '0.00' COMMENT '变动后金额',
  `describe` varchar(100) DEFAULT NULL COMMENT '描述/说明',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ab_customer_balance_logs_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='余额变动明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_customer_balance_logs`
--

LOCK TABLES `cr_customer_balance_logs` WRITE;
/*!40000 ALTER TABLE `cr_customer_balance_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_customer_balance_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_customer_withdraws`
--

DROP TABLE IF EXISTS `cr_customer_withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_customer_withdraws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '提现金额',
  `pay_type` tinyint(3) DEFAULT '10' COMMENT '打款方式(10 微信 20支付宝 30银行卡,暂只有10)',
  `apply_status` tinyint(3) DEFAULT '10' COMMENT '申请状态(10待审核 20审核通过 30驳回 40已打款)',
  `audit_date` datetime DEFAULT NULL COMMENT '审核时间',
  `reject_reason` varchar(255) DEFAULT NULL COMMENT '驳回原因',
  `is_settled` tinyint(3) DEFAULT '0' COMMENT '是否结算 1已结算 0未结算',
  `settle_date` datetime DEFAULT NULL COMMENT '结算时间',
  `payment_no` varchar(150) DEFAULT NULL COMMENT '微信结算单号',
  `total_money` decimal(10,2) DEFAULT '0.00' COMMENT '总金额(提现金额 + 服务费)',
  `service_fee` decimal(10,2) DEFAULT '0.00' COMMENT '服务费',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ab_customer_withdraws_cid_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COMMENT='提现明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_customer_withdraws`
--

LOCK TABLES `cr_customer_withdraws` WRITE;
/*!40000 ALTER TABLE `cr_customer_withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_customer_withdraws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_customers`
--

DROP TABLE IF EXISTS `cr_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(150) DEFAULT NULL COMMENT '昵称',
  `head_img` varchar(255) DEFAULT NULL COMMENT '头像',
  `open_id` varchar(150) DEFAULT NULL,
  `session_key` varchar(150) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '余额',
  `wxphone` varchar(30) DEFAULT NULL COMMENT '微信授权手机号',
  `gender` tinyint(3) DEFAULT '0' COMMENT '性别',
  `pay_money` decimal(10,2) DEFAULT '0.00' COMMENT '用户总支付金额',
  `is_merchant` tinyint(3) DEFAULT '0' COMMENT '是否为商家 1是 0否',
  `ip` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cr_user_open_id_index` (`open_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10002 DEFAULT CHARSET=utf8mb4 COMMENT='小程序用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_customers`
--

LOCK TABLES `cr_customers` WRITE;
/*!40000 ALTER TABLE `cr_customers` DISABLE KEYS */;
INSERT INTO `cr_customers` VALUES (10001,'Ripper','https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTL8ib1mWPZKj7wswBxlbj8mR4Bhicme2VCENHHIeSolMukHibpcAlnZsttu2tibqkuFxTv3boyGR3dQbg/132','o_00h5ZzCIvTkLV240pG5Y3JKrIc','3UGXlRmvAnLrT5iuNRPjZw==',0.00,NULL,0,0.00,0,'59.47.226.240','2022-07-11 13:33:25','2022-07-12 15:22:33',NULL);
/*!40000 ALTER TABLE `cr_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_failed_jobs`
--

DROP TABLE IF EXISTS `cr_failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_failed_jobs`
--

LOCK TABLES `cr_failed_jobs` WRITE;
/*!40000 ALTER TABLE `cr_failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_migrations`
--

DROP TABLE IF EXISTS `cr_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_migrations`
--

LOCK TABLES `cr_migrations` WRITE;
/*!40000 ALTER TABLE `cr_migrations` DISABLE KEYS */;
INSERT INTO `cr_migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2020_09_07_090635_create_admin_settings_table',1),(7,'2020_09_22_015815_create_admin_extensions_table',1),(8,'2020_11_01_083237_update_admin_menu_table',1);
/*!40000 ALTER TABLE `cr_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_password_resets`
--

DROP TABLE IF EXISTS `cr_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `cr_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_password_resets`
--

LOCK TABLES `cr_password_resets` WRITE;
/*!40000 ALTER TABLE `cr_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_personal_access_tokens`
--

DROP TABLE IF EXISTS `cr_personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_personal_access_tokens_token_unique` (`token`),
  KEY `cr_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_personal_access_tokens`
--

LOCK TABLES `cr_personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `cr_personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_settings`
--

DROP TABLE IF EXISTS `cr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(30) DEFAULT NULL COMMENT '设置项标识',
  `describe` varchar(255) DEFAULT NULL COMMENT '设置项描述',
  `values` mediumtext COMMENT '设置项内容(json格式)',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_setting_key_uindex` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='系统设置记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_settings`
--

LOCK TABLES `cr_settings` WRITE;
/*!40000 ALTER TABLE `cr_settings` DISABLE KEYS */;
INSERT INTO `cr_settings` VALUES (1,'system','系统设置','{\"name\":\"\\u6613\\u7f8e\\u6d77\\u6dd8\",\"wechat_app_id\":\"wxe7e2e229beed8335\",\"wechat_app_secret\":\"9c900ab2a8e66120e7d904a72f0cc64c\",\"wechat_payment_mchid\":\"1563463201\",\"wechat_payment_key\":\"DCrnoJTosLfmlbDor7TvvIjljJfkuqzv\",\"wechat_certificate_cert\":\"-----BEGIN CERTIFICATE-----\\r\\nMIID7DCCAtSgAwIBAgIUO88hZ4DFgvdvJVctU+zXRpVXXuIwDQYJKoZIhvcNAQEL\\r\\nBQAwXjELMAkGA1UEBhMCQ04xEzARBgNVBAoTClRlbnBheS5jb20xHTAbBgNVBAsT\\r\\nFFRlbnBheS5jb20gQ0EgQ2VudGVyMRswGQYDVQQDExJUZW5wYXkuY29tIFJvb3Qg\\r\\nQ0EwHhcNMjEwMTE5MDY0MDMyWhcNMjYwMTE4MDY0MDMyWjB+MRMwEQYDVQQDDAox\\r\\nNTYzNDYzMjAxMRswGQYDVQQKDBLlvq7kv6HllYbmiLfns7vnu58xKjAoBgNVBAsM\\r\\nIea3seWcs+W4gue7tOeOm+enkeaKgOaciemZkOWFrOWPuDELMAkGA1UEBgwCQ04x\\r\\nETAPBgNVBAcMCFNoZW5aaGVuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\\r\\nAQEA7ttQP\\/Ih4\\/H4x0yi\\/Z+gYZYmxHg06TfGQhS0OYwA\\/yKtRDp2\\/83T9NYTb0jW\\r\\ndSUhWXnAwW9GVre0Yd3Sgv3E8nvhDxNBc98Vc7pVtBj8JEk\\/4TEIa56jzWLaQeg2\\r\\nJfbFZlfK3cqsYQ0EEROAf+5sZdDeyiHx36yrv8TgZRQCeUzy7\\/hYddWaKViM8Fs6\\r\\nGmvn80Ifx+Wm\\/1MbdQerEhKgdiFcics3B36cGZkzrpXWuGZbRXJ8rgi+s18AYQZk\\r\\nxXtpVoaiKaXbqPpaXCsqNoeqd\\/Wn2IXAjKjXeQ1vsS2UAqWRMzlRJT9w0bLFR14N\\r\\nORLyTYC+OApRpa8iuYq69aYkSQIDAQABo4GBMH8wCQYDVR0TBAIwADALBgNVHQ8E\\r\\nBAMCBPAwZQYDVR0fBF4wXDBaoFigVoZUaHR0cDovL2V2Y2EuaXRydXMuY29tLmNu\\r\\nL3B1YmxpYy9pdHJ1c2NybD9DQT0xQkQ0MjIwRTUwREJDMDRCMDZBRDM5NzU0OTg0\\r\\nNkMwMUMzRThFQkQyMA0GCSqGSIb3DQEBCwUAA4IBAQBN\\/QIsOa0\\/cO4XryEvp9It\\r\\nQJwI28cbrbBt3gH4V+M8GvjjuM0vaxdF0Hkm3ysmGY2Y2HrD\\/ERLOepQU2jYbPgO\\r\\nBtis8hQ1Qal\\/vLiE4DJ5jP65z8ezJedCXsPbCvUS4o0kZSecEFnjKwOtWVCF6E0e\\r\\npPmyPGPatMk8dcTIs23ZEfCzFEUu8yMBy9PceR3ecHVqKvL3\\/AV65jooi0PXYSNy\\r\\nT6k8wGFUG+kXS+O1Mswo5WDxvki\\/MLAfi+Y3EwLnel4jco2V3WRH0Bu+vXjtJUTe\\r\\nVBcNjbShtZsQldyfpeI50TeD6KEqi\\/PP4YhG3DqTW57tg4rla4NpvkkgdICjXVCL\\r\\n-----END CERTIFICATE-----\",\"wechat_certificate_key\":\"-----BEGIN PRIVATE KEY-----\\r\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDu21A\\/8iHj8fjH\\r\\nTKL9n6BhlibEeDTpN8ZCFLQ5jAD\\/Iq1EOnb\\/zdP01hNvSNZ1JSFZecDBb0ZWt7Rh\\r\\n3dKC\\/cTye+EPE0Fz3xVzulW0GPwkST\\/hMQhrnqPNYtpB6DYl9sVmV8rdyqxhDQQR\\r\\nE4B\\/7mxl0N7KIfHfrKu\\/xOBlFAJ5TPLv+Fh11ZopWIzwWzoaa+fzQh\\/H5ab\\/Uxt1\\r\\nB6sSEqB2IVyJyzcHfpwZmTOulda4ZltFcnyuCL6zXwBhBmTFe2lWhqIppduo+lpc\\r\\nKyo2h6p39afYhcCMqNd5DW+xLZQCpZEzOVElP3DRssVHXg05EvJNgL44ClGlryK5\\r\\nirr1piRJAgMBAAECggEASOvbzCn3\\/sdY1D+pYxTguepFW6X3QVwtwu7fNtJvW3US\\r\\nwMm4mtAT7aONu2PZVVpInDB3kJaQOtlK0LYQFr2y6vS2+Qs\\/6EgrHHG+yIT4NXvH\\r\\nbNCzaWe9Sm7rg0OJhH2aNmyHGr9NcTOwEiaKDISVw1\\/JJJzIYyksJhfNCg7Z0n38\\r\\nj3GBVIBQzJcsB\\/GYmRgeE9+yzl\\/tQn0NuhTne0Zn3pCHqHFTtO1ktktrn5KN1z2A\\r\\nnwhfechIiYqgkJ71RzV4+w99qMV6u7IVZrbHTynf3GYKKRQpoEk18ReKq84557RW\\r\\nTtBfc\\/QI6JpKf0u0k4HasVjq5nmiS6KQmKmp2lpUoQKBgQD4ylLGE3XK0l90Fwp+\\r\\n+t2PlRvitWH2b1oYNWg4gWtiAASvB6jxbg85J45QmTOPSriFU2cSQFowGcrKMV2e\\r\\nSr35HyJ\\/5U7eS2yXpA3f08FceS7rmSXjZIwtdW\\/UPTKGXe86GPJUx0CUXDH49W7b\\r\\nhYDD9ERkXZ1zO7h1\\/HCG5tgswwKBgQD1x0vlN9\\/LFIrZMV\\/fh1bGWknGJ99bXma9\\r\\nJMVnGTow\\/R5Wl9JGv2Vvy6f70O3T15PwztIC6nXsPC\\/fck0WpmmAYd03JRSDiwq6\\r\\nHF9wl5OmQDXqbDqsRkWHLr2zKFNrH6sA+nXjcEXwQd+K\\/qMXgfJr7YIAzwFhxolN\\r\\nGBIVtUoKAwKBgE5Vjgh1+iG5aXqpApIGtRpPba9NQyIP34M91ans\\/f2mWdMui0Ax\\r\\nUjPBw6qXAkf80+qO3yY9AuigRlyxfHOpvvUgm4E\\/lzyg7Pk2G3Q9PWW7dk2SM\\/7M\\r\\nGuL5VhOyjSUHkJpvXmXZMvlDqixkQtp1x5xrXdloLHoq9KKZsGiZaLl3AoGBAL4U\\r\\nhUjgPo8z8vJosioQ5HaBC39aBO8IAlMT5iuHIi8TA2ya\\/EBE8\\/FTQzaIbfahSkQ5\\r\\n38frhonOPoQERURYLU3h4hEs90GIviIToWhVghZYoJoNXA8yRcF3z7SIYoN9uWYH\\r\\nTjc49I4MlBNOPdoHYPJBfIKdlgcFYdii3hG15G37AoGBAPKnTkY3z5GnjjY7DXHF\\r\\ncn\\/iyoCRBqDryQg6myi2p7adlszehix7oWTKjKEKUPcHwfVM5zyx50huT1z1fX6b\\r\\n3Eht5t7ssGM6XmKTNiTNqPOk0w5\\/aHlA3rHC6uV5m\\/aQdP73IEHCEOXaDjbexh08\\r\\nqKxyQgMxdoRBypPIRlZ4Bot6\\r\\n-----END PRIVATE KEY-----\",\"withdrawal_fee\":\"2\"}','2022-07-12 13:21:38','2022-07-12 15:14:42',NULL),(2,'full_free','满额包邮设置','{\"is_open\":\"1\",\"money\":\"0\"}','2022-07-12 13:22:54','2022-07-12 13:22:54',NULL);
/*!40000 ALTER TABLE `cr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cr_users`
--

DROP TABLE IF EXISTS `cr_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cr_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cr_users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cr_users`
--

LOCK TABLES `cr_users` WRITE;
/*!40000 ALTER TABLE `cr_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `cr_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'huanrenka'
--

--
-- Dumping routines for database 'huanrenka'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-12 15:26:44
